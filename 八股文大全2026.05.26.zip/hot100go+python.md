## 1.两数之和

go:

```go
func twoSum(nums []int, target int) []int {
    hashTable := map[int]int{}
    for i,x := range nums{
        if p,ok := hashTable[target - x]; ok {
            return []int{p,i}
        }
        hashTable[x] = i
    }
    return nil
}
```

python:

```python
class Solution:
    def twoSum(self, nums: List[int], target: int) -> List[int]:
        hashtable = dict()
        for i,num in enumerate(nums):
            if target - num in hashtable:
                return [hashtable[target - num],i]
            hashtable[nums[i]] = i
        return []
```

## 2.字母异位词分组

go:

```go
func groupAnagrams(strs []string) [][]string {
    mp := map[[26]int][]string{}
    for _,str := range strs{
        cnt := [26]int{}
        for _,b := range str{
            cnt[b - 'a'] ++
        }
        mp[cnt] = append(mp[cnt],str)
    }
    ans := make([][]string,0,len(mp))
    for _,v := range mp{
        ans = append(ans,v)
    }
    return ans
}
```

python:

```py
class Solution:
    def groupAnagrams(self, strs: List[str]) -> List[List[str]]:
        mp = collections.defaultdict(list)

        for str in strs:
            counts = [0] * 26
            for ch in str:
                counts[ord(ch) - ord('a')] += 1
            mp[tuple(counts)].append(str)
        
        return list(mp.values())
```

## 3.最长连续序列

go:

```go
func longestConsecutive(nums []int) int {
    numSet := map[int]bool{}
    for _,num := range nums{
        numSet[num] = true
    }
    longestStreak := 0
    for num := range numSet{
        if !numSet[num - 1]{
            currentStreak := 1
            currentNum := num
            for numSet[currentNum + 1]{
                currentNum ++
                currentStreak ++
            }
            if longestStreak < currentStreak{
                longestStreak = currentStreak
            }
        }
    }
    return longestStreak
}
```

python:

```python
class Solution:
    def longestConsecutive(self, nums: List[int]) -> int:
        longest_streak = 0
        num_set = set(nums)
        for num in num_set :
            if num - 1 not in num_set:
                current_num = num
                current_streak = 1
                while current_num + 1 in num_set:
                    current_num += 1
                    current_streak += 1
                longest_streak = max(longest_streak,current_streak)
        return longest_streak
```

## 4.移动零

go:

```go
func moveZeroes(nums []int)  {
    left,right,n := 0,0,len(nums)
    for right < n{
        if nums[right] != 0{
            nums[left],nums[right] = nums[right],nums[left]
            left ++
        }
        right ++
    }
}
```

python:

```python
class Solution:
    def moveZeroes(self, nums: List[int]) -> None:
        n = len(nums)
        left = right = 0
        while right < n:
            if nums[right] != 0:
                nums[left],nums[right] = nums[right],nums[left]
                left += 1
            right += 1
```

## 5.盛最多水的容器

go:

```go
func maxArea(height []int) (ans int) {
   l,r := 0,len(height) - 1
   ans = 0
    for l < r{
        area := (r - l) * min(height[l],height[r])
        ans = max(area,ans)
        if (height[l] <= height[r]){
            l ++
        }else{
            r --
        }
    }
    return ans
}
```



python:

```python
class Solution:
    def maxArea(self, height: List[int]) -> int:
        l,r = 0,len(height) - 1
        ans = 0
        while l < r:
            area = min(height[l],height[r]) * (r - l)
            ans = max(ans,area)
            if height[l] <= height[r]:
                l += 1
            else:
                r -= 1
        return ans
```

## 6.三数之和

go:

```go
func threeSum(nums []int) (ans [][]int) {
    slices.Sort(nums)
    n := len(nums)
    for i,x := range nums[:n-2]{
        
        if i > 0 && x == nums[i - 1]{
            continue
        }
        if x + nums[i + 1] + nums[i + 2] > 0{
            break
        }
        if x + nums[n - 1] + nums[n - 2] < 0{
            continue
        }

        l := i + 1
        r := n - 1
        for l < r{
            s := x + nums[l] + nums[r]
            if s > 0{
                r --
            }else if s < 0{
                l ++
            }else{
                ans = append(ans,[]int{x,nums[l],nums[r]})
                for l ++; l < r && nums[l] == nums[l - 1];l ++{

                }
                for r --; l < r && nums[r] == nums[r + 1];r --{

                }
            }
        }
    }
    return ans
}
```

python:

```python
class Solution:
    def threeSum(self, nums: list[int]) -> list[list[int]]:
        ans = []
        nums.sort()
        n = len(nums)
        for i in range(n - 2):
            x = nums[i]
            if i > 0 and x == nums[i - 1]:
                continue
            if x + nums[i + 1] + nums[i + 2] > 0:
                break
            if x + nums[-1] + nums[-2] < 0:
                continue
            l = i + 1
            r = n - 1
            while l < r:
                s = x + nums[l] + nums[r]
                if s > 0:
                    r -= 1
                elif s < 0:
                    l += 1
                else:
                    ans.append([x,nums[l],nums[r]])
                    l += 1
                    while l < r and nums[l] == nums[l - 1]:
                        l += 1
                    r -= 1
                    while l < r and nums[r] == nums[r + 1]:
                        r -= 1
        return ans
```

## 7.接雨水

go:

```go
func trap(height []int) (ans int) {
    ans = 0
    st := []int{}
    for i,h := range height{
        for len(st) > 0 && height[st[len(st) - 1]] <= h{
            bottomH := height[st[len(st) - 1]]
            st = st[:len(st) - 1]
            if len(st) == 0{
                break
            }
            left := st[len(st) - 1]
            dh := min(height[left],h) - bottomH
            ans += dh * (i - left - 1)
        }
        st = append(st,i)
    }
    return ans
}
```

python:

```python
class Solution:
    def trap(self, height: List[int]) -> int:
        st = []
        ans = 0
        for i,h in enumerate(height):
            while st and height[st[-1]] <= h:
                bottom_h = height[st.pop()]
                if not st:
                    break
                left = st[-1]
                dh = min(height[left],h) - bottom_h
                ans += dh * (i - left - 1)
            st.append(i)
        return ans
```

## 8.无重复字符的最长字串

go:

```go
func lengthOfLongestSubstring(s string) (ans int) {
    cnt := [128]int{}
    left := 0
    for right,c := range s{
        cnt[c] ++
        for cnt[c] > 1{
            cnt[s[left]] --
            left ++
        }
        ans = max(ans,right - left + 1)
    }
    return ans
}
```

python:

```python
class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        ans = left = 0
        cnt = defaultdict(int)
        for right,c in enumerate(s):
            cnt[c] += 1
            while cnt[c] > 1:
                cnt[s[left]] -= 1
                left += 1
            ans = max(ans,right - left + 1)
        return ans
```

## 9.找到字符串中所有字母异位词

go:

```go
func findAnagrams(s, p string) (ans []int) {
    // 统计 p 的每种字母的出现次数
    cnt := [26]int{}
    for _, c := range p {
        cnt[c-'a']++
    }

    left := 0
    for right, c := range s {
        c -= 'a'
        cnt[c]-- // 右端点字母进入窗口
        for cnt[c] < 0 { // 字母 c 太多了
            cnt[s[left]-'a']++ // 左端点字母离开窗口
            left++
        }
        if right-left+1 == len(p) { // t 和 p 的每种字母的出现次数都相同（证明见上）
            ans = append(ans, left) // t 左端点下标加入答案
        }
    }
    return
}

```

python:

```python
# 请选择 Python3 提交代码，而不是 Python
class Solution:
    def findAnagrams(self, s: str, p: str) -> List[int]:
        cnt = Counter(p)  # 统计 p 的每种字母的出现次数
        ans = []

        left = 0
        for right, c in enumerate(s):
            cnt[c] -= 1  # 右端点字母进入窗口
            while cnt[c] < 0:  # 字母 c 太多了
                cnt[s[left]] += 1  # 左端点字母离开窗口
                left += 1
            if right - left + 1 == len(p):  # t 和 p 的每种字母的出现次数都相同（证明见上）
                ans.append(left)  # t 左端点下标加入答案

        return ans

```

## 10.和为k的子数组

go:

```go
func subarraySum(nums []int, k int) (ans int) {
    cnt := make(map[int]int,len(nums) + 1)
    cnt[0] = 1
    s := 0
    for _,x := range nums{
        s += x
        ans += cnt[s - k]
        cnt[s] ++
    }
    return 
}
```

python:

```python
class Solution:
    def subarraySum(self, nums: List[int], k: int) -> int:
        cnt = defaultdict(int)
        cnt[0] = 1  # s[0]=0 单独统计
        ans = s = 0
        for x in nums:
            s += x
            ans += cnt[s - k]
            cnt[s] += 1
        return ans
```

## 11.滑动窗口最大值

go:

```go
func maxSlidingWindow(nums []int, k int) []int {
    ans := make([]int, len(nums)-k+1) // 窗口个数
    q := []int{}

    for i, x := range nums {
        // 1. 右边入
        for len(q) > 0 && nums[q[len(q)-1]] <= x {
            q = q[:len(q)-1] // 维护 q 的单调性
        }
        q = append(q, i) // 注意保存的是下标，这样下面可以判断队首是否离开窗口

        // 2. 左边出
        left := i - k + 1 // 窗口左端点
        if q[0] < left {  // 队首离开窗口
            q = q[1:] // Go 的切片是 O(1) 的
        }

        // 3. 在窗口左端点处记录答案
        if left >= 0 {
            // 由于队首到队尾单调递减，所以窗口最大值就在队首
            ans[left] = nums[q[0]]
        }
    }

    return ans
}

```

python:

```python
class Solution:
    def maxSlidingWindow(self, nums: List[int], k: int) -> List[int]:
        ans = [0] * (len(nums) - k + 1)  # 窗口个数
        q = deque()  # 双端队列

        for i, x in enumerate(nums):
            # 1. 右边入
            while q and nums[q[-1]] <= x:
                q.pop()  # 维护 q 的单调性
            q.append(i)  # 注意保存的是下标，这样下面可以判断队首是否离开窗口

            # 2. 左边出
            left = i - k + 1  # 窗口左端点
            if q[0] < left:  # 队首离开窗口
                q.popleft()

            # 3. 在窗口左端点处记录答案
            if left >= 0:
                # 由于队首到队尾单调递减，所以窗口最大值就在队首
                ans[left] = nums[q[0]]

        return ans

```

## 12.最小覆盖子串

go:

```go
func isCovered(cntS, cntT []int) bool {
    for i := 'A'; i <= 'Z'; i++ {
        if cntS[i] < cntT[i] {
            return false
        }
    }
    for i := 'a'; i <= 'z'; i++ {
        if cntS[i] < cntT[i] {
            return false
        }
    }
    return true
}

func minWindow(s, t string) string {
    var cntS, cntT [128]int
    for _, c := range t {
        cntT[c]++
    }

    ansLeft, ansRight := -1, len(s)
    left := 0

    for right, c := range s { // 移动子串右端点
        cntS[c]++ // 右端点字母移入子串
        for isCovered(cntS[:], cntT[:]) { // 涵盖
            if right-left < ansRight-ansLeft { // 找到更短的子串
                ansLeft, ansRight = left, right // 记录此时的左右端点
            }
            cntS[s[left]]-- // 左端点字母移出子串
            left++
        }
    }

    if ansLeft < 0 {
        return ""
    }
    return s[ansLeft : ansRight+1]
}
```

python:

```python
# 请选择 Python3 提交代码，而不是 Python
class Solution:
    def minWindow(self, s: str, t: str) -> str:
        cnt_s = Counter()  # s 子串字母的出现次数
        cnt_t = Counter(t)  # t 中字母的出现次数

        ans_left, ans_right = -1, len(s)
        left = 0

        for right, c in enumerate(s):  # 移动子串右端点
            cnt_s[c] += 1  # 右端点字母移入子串
            while cnt_s >= cnt_t:  # 涵盖
                if right - left < ans_right - ans_left:  # 找到更短的子串
                    ans_left, ans_right = left, right  # 记录此时的左右端点
                cnt_s[s[left]] -= 1  # 左端点字母移出子串
                left += 1

        return "" if ans_left < 0 else s[ans_left: ans_right + 1]

```

## 13.最大子数组和

go:

```go
func maxSubArray(nums []int) int {
    ans := math.MinInt // 注意答案可以是负数，不能初始化成 0
    f := 0
    for _, x := range nums {
        f = max(f, 0) + x
        ans = max(ans, f)
    }
    return ans
}
```

python:

```python
class Solution:
    def maxSubArray(self, nums: List[int]) -> int:
        ans = -inf
        f = 0
        for x in nums:
            f = max(f,0) + x
            ans = max(ans,f)
        return ans
```

## 14.合并区间

go:

```go
func merge(intervals [][]int) (ans [][]int) {
    slices.SortFunc(intervals, func(p, q []int) int { return p[0] - q[0] }) // 按照左端点从小到大排序

    for _, p := range intervals {
        m := len(ans)
        if m > 0 && p[0] <= ans[m-1][1] { // 左端点在合并区间内，可以合并
            ans[m-1][1] = max(ans[m-1][1], p[1]) // 更新合并区间的右端点
        } else { // 不相交，无法合并
            ans = append(ans, p) // 新的合并区间
        }
    }
    return
}
```

python:

```##python
class Solution:
    def merge(self, intervals: List[List[int]]) -> List[List[int]]:
        intervals.sort(key=lambda p: p[0])  # 按照左端点从小到大排序

        ans = []
        for p in intervals:
            if ans and p[0] <= ans[-1][1]:  # 左端点在合并区间内，可以合并
                ans[-1][1] = max(ans[-1][1], p[1])  # 更新合并区间的右端点
            else:  # 不相交，无法合并
                ans.append(p)  # 新的合并区间
        return ans
```

## 15.轮转数组

go

```go
func rotate(nums []int, k int) {
    k %= len(nums) // 轮转 k 次等于轮转 k % n 次
    slices.Reverse(nums)
    slices.Reverse(nums[:k])
    slices.Reverse(nums[k:])
}
```

python

```python
# 注：请勿使用切片，会产生额外空间
class Solution:
    def rotate(self, nums: List[int], k: int) -> None:
        def reverse(i: int, j: int) -> None:
            while i < j:
                nums[i], nums[j] = nums[j], nums[i]
                i += 1
                j -= 1

        n = len(nums)
        k %= n  # 轮转 k 次等于轮转 k % n 次
        reverse(0, n - 1)
        reverse(0, k - 1)
        reverse(k, n - 1)
```

## 16.除了自身以外数组的乘积

go

```go
func productExceptSelf(nums []int) []int {
    n := len(nums)
    suf := make([]int,n)
    suf[n - 1] = 1
    for i := n - 2;i >= 0;i --{
        suf[i] = suf[i + 1]*nums[i + 1]
    }
    pre := 1
    for i,x := range nums{
        suf[i] *= pre
        pre *= x
    }
    return suf
}
```

python

```python
class Solution:
    def productExceptSelf(self, nums: List[int]) -> List[int]:
        n = len(nums)
        suf = [1] * n
        for i in range (n - 2,-1,-1):
            suf[i] = suf[i + 1] * nums[i + 1]
        
        pre = 1
        for i,x in enumerate(nums):
            suf[i] *= pre
            pre *= x
        return suf
```

## 17.缺失的第一个正数

go

```go
func firstMissingPositive(nums []int) int {
    n := len(nums)
    for i := range n {
        // 如果当前学生的学号在 [1,n] 中，但（真身）没有坐在正确的座位上
        for 1 <= nums[i] && nums[i] <= n && nums[nums[i]-1] != nums[i] {
            // 那么就交换 nums[i] 和 nums[j]，其中 j 是 i 的学号
            j := nums[i] - 1 // 减一是因为数组下标从 0 开始
            nums[i], nums[j] = nums[j], nums[i]
        }
    }

    // 找第一个学号与座位编号不匹配的学生
    for i := range n {
        if nums[i] != i+1 {
            return i + 1
        }
    }

    // 所有学生都坐在正确的座位上
    return n + 1
}
```

python

```python
class Solution:
    def firstMissingPositive(self, nums: list[int]) -> int:
        n = len(nums)
        for i in range(n):
            # 如果当前学生的学号在 [1,n] 中，但（真身）没有坐在正确的座位上
            while 1 <= nums[i] <= n and nums[nums[i] - 1] != nums[i]:
                # 那么就交换 nums[i] 和 nums[j]，其中 j 是 i 的学号
                j = nums[i] - 1  # 减一是因为数组下标从 0 开始
                nums[i], nums[j] = nums[j], nums[i]

        # 找第一个学号与座位编号不匹配的学生
        for i in range(n):
            if nums[i] != i + 1:
                return i + 1

        # 所有学生都坐在正确的座位上
        return n + 1
```

## 18.矩阵置零

python

```python
class Solution:
    def setZeroes(self, matrix: List[List[int]]) -> None:
        m, n = len(matrix), len(matrix[0])
        first_row_has_zero = 0 in matrix[0]

        for i in range(1, m):
            for j in range(n):
                if matrix[i][j] == 0:
                    matrix[i][0] = matrix[0][j] = 0

        for i in range(1, m):
            # 倒着遍历，避免提前把 matrix[i][0] 改成 0，误认为这一行要全部变成 0
            for j in range(n - 1, -1, -1):
                if matrix[i][0] == 0 or matrix[0][j] == 0:
                    matrix[i][j] = 0

        if first_row_has_zero:
            for j in range(n):
                matrix[0][j] = 0
```

go

```go
func setZeroes(matrix [][]int) {
    m, n := len(matrix), len(matrix[0])
    firstRowHasZero := slices.Contains(matrix[0], 0)

    for i := 1; i < m; i++ {
        for j, x := range matrix[i] {
            if x == 0 {
                matrix[i][0] = 0
                matrix[0][j] = 0
            }
        }
    }

    for i := 1; i < m; i++ {
        // 倒着遍历，避免提前把 matrix[i][0] 改成 0，误认为这一行要全部变成 0
        for j := n - 1; j >= 0; j-- {
            if matrix[i][0] == 0 || matrix[0][j] == 0 {
                matrix[i][j] = 0
            }
        }
    }

    if firstRowHasZero {
        clear(matrix[0])
    }
}
```

## 19.螺旋矩阵

go

```go
var dirs = [4][2]int{{0, 1}, {1, 0}, {0, -1}, {-1, 0}} // 右下左上

func spiralOrder(matrix [][]int) []int {
    m, n := len(matrix), len(matrix[0])
    ans := make([]int, 0, m*n)
    i, j := 0, -1 // 从 (0, -1) 开始
    for di := 0; len(ans) < cap(ans); di = (di + 1) % 4 {
        for range n { // 走 n 步（注意 n 会减少）
            i += dirs[di][0]
            j += dirs[di][1] // 先走一步
            ans = append(ans, matrix[i][j]) // 再加入答案
        }
        m, n = n, m-1 // 减少后面的循环次数
    }
    return ans
}
```

python

```python
DIRS = (0, 1), (1, 0), (0, -1), (-1, 0)  # 右下左上

class Solution:
    def spiralOrder(self, matrix: List[List[int]]) -> List[int]:
        m, n = len(matrix), len(matrix[0])
        size = m * n
        ans = []
        i, j, di = 0, -1, 0  # 从 (0, -1) 开始
        while len(ans) < size:
            dx, dy = DIRS[di]
            for _ in range(n):  # 走 n 步（注意 n 会减少）
                i += dx
                j += dy  # 先走一步
                ans.append(matrix[i][j])  # 再加入答案
            di = (di + 1) % 4  # 右转 90°
            m, n = n, m - 1  # 减少后面的循环次数（步数）
        return ans
```

## 20.旋转图像

go

```go
func rotate(matrix [][]int) {
    n := len(matrix)
    // 第一步：转置
    for i := range n {
        for j := range i { // 遍历对角线下方元素
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
        }
    }

    // 第二步：行翻转
    for _, row := range matrix {
        slices.Reverse(row)
    }
}
```

python

```python
class Solution:
    def rotate(self, matrix: List[List[int]]) -> None:
        n = len(matrix)
        # 第一步：转置
        for i in range(n):
            for j in range(i):  # 遍历对角线下方元素
                matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]

        # 第二步：行翻转
        for row in matrix:
            row.reverse()
```

## 21.搜索二维矩阵

go

```
func searchMatrix(matrix [][]int, target int) bool {
    m, n := len(matrix), len(matrix[0])
    i, j := 0, n-1 // 从右上角开始
    for i < m && j >= 0 { // 还有剩余元素
        if matrix[i][j] == target {
            return true // 找到 target
        }
        if matrix[i][j] < target {
            i++ // 这一行剩余元素全部小于 target，排除
        } else {
            j-- // 这一列剩余元素全部大于 target，排除
        }
    }
    return false
}
```

python

```
class Solution:
    def searchMatrix(self, matrix: List[List[int]], target: int) -> bool:
        m, n = len(matrix), len(matrix[0])
        i, j = 0, n - 1  # 从右上角开始
        while i < m and j >= 0:  # 还有剩余元素
            if matrix[i][j] == target:
                return True  # 找到 target
            if matrix[i][j] < target:
                i += 1  # 这一行剩余元素全部小于 target，排除
            else:
                j -= 1  # 这一列剩余元素全部大于 target，排除
        return False
```

## 22.相交链表

go

```
func getIntersectionNode(headA, headB *ListNode) *ListNode {
    p, q := headA, headB
    for p != q {
        if p != nil {
            p = p.Next
        } else {
            p = headB
        }
        if q != nil {
            q = q.Next
        } else {
            q = headA
        }
    }
    return p
}
```

python

```python
class Solution:
    def getIntersectionNode(self, headA: ListNode, headB: ListNode) -> Optional[ListNode]:
        p, q = headA, headB
        while p is not q:
            p = p.next if p else headB
            q = q.next if q else headA
        return p
```

## 23.反转链表

go

```go
func reverseList(head *ListNode) *ListNode {
    var pre, cur *ListNode = nil, head
    for cur != nil {
        nxt := cur.Next
        cur.Next = pre // 把 cur 插在 pre 链表的前面（头插法）
        pre = cur
        cur = nxt
    }
    return pre
}
```

python

```
class Solution:
    def reverseList(self, head: Optional[ListNode]) -> Optional[ListNode]:
        pre = None
        cur = head
        while cur:
            nxt = cur.next
            cur.next = pre  # 把 cur 插在 pre 链表的前面（头插法）
            pre = cur
            cur = nxt
        return pre
```

## 24.回文链表

go

```
// 876. 链表的中间结点
func middleNode(head *ListNode) *ListNode {
    slow, fast := head, head
    for fast != nil && fast.Next != nil {
        slow = slow.Next
        fast = fast.Next.Next
    }
    return slow
}

// 206. 反转链表
func reverseList(head *ListNode) *ListNode {
    var pre, cur *ListNode = nil, head
    for cur != nil {
        nxt := cur.Next
        cur.Next = pre
        pre = cur
        cur = nxt
    }
    return pre
}

func isPalindrome(head *ListNode) bool {
    mid := middleNode(head)
    head2 := reverseList(mid)
    for head2 != nil {
        if head.Val != head2.Val { // 不是回文链表
            return false
        }
        head = head.Next
        head2 = head2.Next
    }
    return true
}
```

python

```
class Solution:
    # 876. 链表的中间结点
    def middleNode(self, head: Optional[ListNode]) -> Optional[ListNode]:
        slow = fast = head
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
        return slow

    # 206. 反转链表
    def reverseList(self, head: Optional[ListNode]) -> Optional[ListNode]:
        pre, cur = None, head
        while cur:
            nxt = cur.next
            cur.next = pre
            pre = cur
            cur = nxt
        return pre

    def isPalindrome(self, head: Optional[ListNode]) -> bool:
        mid = self.middleNode(head)
        head2 = self.reverseList(mid)
        while head2:
            if head.val != head2.val:  # 不是回文链表
                return False
            head = head.next
            head2 = head2.next
        return True
```



## 25.环形链表

go

```
func hasCycle(head *ListNode) bool {
    slow, fast := head, head // 乌龟和兔子同时从起点出发
    for fast != nil && fast.Next != nil {
        slow = slow.Next // 乌龟走一步
        fast = fast.Next.Next // 兔子走两步
        if fast == slow { // 兔子追上乌龟（套圈），说明有环
            return true
        }
    }
    return false // 访问到了链表末尾，无环
}
```

python

```
class Solution:
    def hasCycle(self, head: Optional[ListNode]) -> bool:
        slow = fast = head  # 乌龟和兔子同时从起点出发
        while fast and fast.next:
            slow = slow.next  # 乌龟走一步
            fast = fast.next.next  # 兔子走两步
            if fast is slow:  # 兔子追上乌龟（套圈），说明有环
                return True
        return False  # 访问到了链表末尾，无环
```

## 26.环形链表2

go

```
func detectCycle(head *ListNode) *ListNode {
    slow, fast := head, head
    for fast != nil && fast.Next != nil {
        slow = slow.Next
        fast = fast.Next.Next
        if fast == slow { // 相遇
            for slow != head { // 再走 a 步
                slow = slow.Next
                head = head.Next
            }
            return slow
        }
    }
    return nil
}
```

python

```
class Solution:
    def detectCycle(self, head: Optional[ListNode]) -> Optional[ListNode]:
        slow = fast = head
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
            if fast is slow:  # 相遇
                while slow is not head:  # 再走 a 步
                    slow = slow.next
                    head = head.next
                return slow
        return None
```



## 27.两数相加

go

```
// l1 和 l2 为当前遍历的节点，carry 为进位
func addTwo(l1 *ListNode, l2 *ListNode, carry int) *ListNode {
    if l1 == nil && l2 == nil && carry == 0 { // 递归边界
        return nil
    }

    s := carry
    if l1 != nil {
        s += l1.Val // 累加进位与节点值
        l1 = l1.Next
    }
    if l2 != nil {
        s += l2.Val
        l2 = l2.Next
    }

    // s 除以 10 的余数为当前节点值，商为进位
    return &ListNode{s % 10, addTwo(l1, l2, s/10)}
}

func addTwoNumbers(l1 *ListNode, l2 *ListNode) *ListNode {
    return addTwo(l1, l2, 0)
}
```

python

```
class Solution:
    # l1 和 l2 为当前遍历的节点，carry 为进位
    def addTwoNumbers(self, l1: Optional[ListNode], l2: Optional[ListNode], carry=0) -> Optional[ListNode]:
        if l1 is None and l2 is None and carry == 0:  # 递归边界
            return None

        s = carry
        if l1:
            s += l1.val  # 累加进位与节点值
            l1 = l1.next
        if l2:
            s += l2.val
            l2 = l2.next

        # s 除以 10 的余数为当前节点值，商为进位
        return ListNode(s % 10, self.addTwoNumbers(l1, l2, s // 10))
```

## 28.删除链表的倒数第N个结点

go

```
func removeNthFromEnd(head *ListNode, n int) *ListNode {
    // 由于可能会删除链表头部，用哨兵节点简化代码
    dummy := &ListNode{Next: head}
    left, right := dummy, dummy
    for ; n > 0; n-- {
        right = right.Next // 右指针先向右走 n 步
    }
    for right.Next != nil {
        left = left.Next
        right = right.Next // 左右指针一起走
    }
    left.Next = left.Next.Next // 左指针的下一个节点就是倒数第 n 个节点
    return dummy.Next
}
```

python

```
class Solution:
    def removeNthFromEnd(self, head: Optional[ListNode], n: int) -> Optional[ListNode]:
        # 由于可能会删除链表头部，用哨兵节点简化代码
        left = right = dummy = ListNode(next=head)
        for _ in range(n):
            right = right.next  # 右指针先向右走 n 步
        while right.next:
            left = left.next
            right = right.next  # 左右指针一起走
        left.next = left.next.next  # 左指针的下一个节点就是倒数第 n 个节点
        return dummy.next
```

## 29.两两交换链表中的结点

go

```
func swapPairs(head *ListNode) *ListNode {
    dummy := &ListNode{Next: head} // 用哨兵节点简化代码逻辑
    node0 := dummy
    node1 := head
    for node1 != nil && node1.Next != nil { // 至少有两个节点
        node2 := node1.Next
        node3 := node2.Next

        node0.Next = node2 // 0 -> 2
        node2.Next = node1 // 2 -> 1
        node1.Next = node3 // 1 -> 3

        node0 = node1 // 下一轮交换，0 是 1
        node1 = node3 // 下一轮交换，1 是 3
    }
    return dummy.Next // 返回新链表的头节点
}
```

python

```
class Solution:
    def swapPairs(self, head: Optional[ListNode]) -> Optional[ListNode]:
        node0 = dummy = ListNode(next=head)  # 用哨兵节点简化代码逻辑
        node1 = head
        while node1 and node1.next:  # 至少有两个节点
            node2 = node1.next
            node3 = node2.next

            node0.next = node2  # 0 -> 2
            node2.next = node1  # 2 -> 1
            node1.next = node3  # 1 -> 3

            node0 = node1  # 下一轮交换，0 是 1
            node1 = node3  # 下一轮交换，1 是 3
        return dummy.next  # 返回新链表的头节点
```

## 30.K个一组翻转链表

go

```
func reverseKGroup(head *ListNode, k int) *ListNode {
    // 统计节点个数
    n := 0
    for cur := head; cur != nil; cur = cur.Next {
        n++
    }

    dummy := &ListNode{Next: head}
    p0 := dummy
    var pre *ListNode
    cur := p0.Next

    // k 个一组处理
    for ; n >= k; n -= k {
        for i := 0; i < k; i++ {
            nxt := cur.Next
            cur.Next = pre // 每次循环只修改一个 Next，方便大家理解
            pre = cur
            cur = nxt
        }

        // 见视频
        nxt := p0.Next
        p0.Next.Next = cur
        p0.Next = pre
        p0 = nxt
    }
    return dummy.Next
}
```

python

```
class Solution:
    def reverseKGroup(self, head: Optional[ListNode], k: int) -> Optional[ListNode]:
        # 统计节点个数
        n = 0
        cur = head
        while cur:
            n += 1
            cur = cur.next

        p0 = dummy = ListNode(next=head)
        pre = None
        cur = head

        # k 个一组处理
        while n >= k:
            n -= k
            for _ in range(k):  # 同 92 题
                nxt = cur.next
                cur.next = pre  # 每次循环只修改一个 next，方便大家理解
                pre = cur
                cur = nxt

            # 见视频
            nxt = p0.next
            nxt.next = cur
            p0.next = pre
            p0 = nxt
        return dummy.next
```

## 31.随机链表的复制

go

```
```

python

```
```

